export class Room {
    id: number;
    name: string;
    date:string
    startHour: string;
    endHour: string;
    active: boolean;
}